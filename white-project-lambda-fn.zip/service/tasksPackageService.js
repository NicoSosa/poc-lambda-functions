const { DynamoDBClient, GetItemCommand, PutItemCommand } = require("@aws-sdk/client-dynamodb");
const { marshall, unmarshall } = require("@aws-sdk/util-dynamodb");
const db = new DynamoDBClient({ region: 'sa-east-1' });

const util = require('../utils/util');

const tasksPackageTable = 'TasksPackagesTable';


const getAllTasksPackagesAsync = async () => {};

const createTasksPackageAsync = async (newTasksPackage) => {};

const getTasksPackageByIdAsync = async (tasksPackageId) => {
    const dbTasksPackage = await getTasksPackageFromDbAsync(tasksPackageId);
    if ( !validateTaskPackageExist(dbTasksPackage) ) return tasksPackageDoesNotExistResponse()

    const tasksPackageResponse = {
        id: tasksPackageId,
        ...dbTasksPackage.data
    }
    return util.buildResponse(200, tasksPackageResponse);

};

const updateTasksPackageAsync = async (tasksPackageId, tasksPackageBody) => {
    const dbTasksPackage = await getTasksPackageFromDbAsync(tasksPackageId);
    if ( !validateTaskPackageExist(dbTasksPackage) ) return tasksPackageDoesNotExistResponse()

    const newTaskPackageData = {
        ...tasksPackageBody
    };

    const updateResponse = await updateTasksPackageAsync(tasksPackageId, newTaskPackageData);

    if (!updateResponse) return serverErrorResponse

    return util.buildResponse(200, {
        message: 'Tasks Package data updated successfully',
        metadata: updateResponse,
        newTaskPackageData
    });

};

const deleteTasksPackageAsync = async (tasksPackageId) => {
    const dbTasksPackage = await getTasksPackageFromDbAsync(tasksPackageId);
    if ( !validateTaskPackageExist(dbTasksPackage) ) return tasksPackageDoesNotExistResponse()
    // TODO : DELETE PROCESS

};

// NOT EXPORTED FUNCTIONS
const getTasksPackageFromDbAsync = async (tasksPackageId) => {
    const params = {
        TableName: tasksPackageTable,
        Key: marshall({ tasksPackageId })
    };

    try {
        const command = new GetItemCommand(params);
        const response = await db.send(command);
        return unmarshall(response.Item);
    } catch (e) {
        return e;
    }
};

const updateTasksPackageAsync = async (tasksPackageId, newTaskPackageData) => {
    const params = {
        TableName: tasksPackageTable,
        Item: marshall({
            userName: tasksPackageId,
            data: {
                ...newTaskPackageData
            }
        }),
    } 
    
    try {
        const command = new PutItemCommand(params);
        const response = await db.send(command);
        return response
    } catch (e) {
        return e
    }
};

const validateTaskPackageExist = (tasksPackage) => {
    if ( !tasksPackage || !tasksPackage.data || !tasksPackage.tasksPackageId ) return false
    return true
};

const tasksPackageDoesNotExistResponse = () => util.buildResponse(400, { message: 'Tasks Package does not exists' });
const serverErrorResponse = () => util.buildResponse(503, { message: 'Server Error. Please try again later.'});

module.exports = {
    getAllTasksPackagesAsync,
    createTasksPackageAsync,
    getTasksPackageByIdAsync,
    updateTasksPackageAsync,
    deleteTasksPackageAsync
};