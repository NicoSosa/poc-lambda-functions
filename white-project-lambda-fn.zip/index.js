const util = require('./utils/util')

const tasksPackageService = require('./service/tasksPackageService');

const tasksPackagePath = '/tasksPackage';
const tasksPackageIdPath = `${tasksPackagePath}/{id}`;

exports.handler = async (event, context, callback) => {
    let response;
    let id;
    let body; 
    
    console.log('Request Event', event);
    switch (true) {
        // TasksPackageAsync
        case event.httpMethod === 'GET' && event.path === tasksPackagePath:
            response = util.buildResponse(200, {message: 'Handle Get All Method'});
            // response = await tasksPackageService.getAllTasksPackagesAsync();
            break;
            
        case event.httpMethod === 'POST' && event.path === tasksPackagePath:
            body = JSON.parse(event.body);
            // response = await tasksPackageService.createTasksPackageAsync(newTasksPackage);
            response = util.buildResponse(200, {message:'Handle Create Method', body});
            break;

        case event.httpMethod === 'GET' && event.path === tasksPackageIdPath:
            id = event.pathParameters.id;
            response = await tasksPackageService.getTasksPackageByIdAsync(id);
            break;

        case event.httpMethod === 'PUT' && event.path === tasksPackageIdPath:
            id = event.pathParameters.id;
            body = JSON.parse(event.body);
            response = await tasksPackageService.updateTasksPackageAsync(id, body);
            break;
        case event.httpMethod === 'DELETE' && event.path === tasksPackageIdPath:
            id = event.pathParameters.id;
            // response = await tasksPackageService.deleteTasksPackageAsync(id);
            response = util.buildResponse(200, {message:'Handle Delete Method', id});
            break;
        
        default:
            response = util.buildResponse(404, '404 - Not Found');
    }
    return response;
};
