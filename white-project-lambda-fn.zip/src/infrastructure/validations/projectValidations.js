const projectResponse = require('../messages/projectResponses')

const validateNewProjectData = (project) => {   
    let hasError;
    let errorResponse

    ({ hasError, errorResponse} = validateProject(project))
    if(hasError) return { hasError, errorResponse }

    ({ hasError, errorResponse} = validateProjectWorkspaceId(project))
    if(hasError) return { hasError, errorResponse }

    ({ hasError, errorResponse} = validateProjectDetails(project))
    if(hasError) return { hasError, errorResponse }

    ({ hasError, errorResponse} = validateProjectUsers(project))
    if(hasError) return { hasError, errorResponse }

    ({ hasError, errorResponse} = validateProjectTasksIncidences(project))
    if(hasError) return { hasError, errorResponse }
}


const validateProject = (project) => {
    if (!project) return { hasError: true, errorResponse: projectResponse.projectRequestHasNotWorkspaceIdResponse }
    return { hasError: false }
}

const validateProjectWorkspaceId = (project) => {
    if (!project.workspaceId) return { hasError: true, errorResponse: projectResponse.projectRequestHasNotWorkspaceIdResponse }
    return { hasError: false }
}

const validateProjectDetails = (project) => {
    if (!project.details) return { hasError: true, errorResponse: projectResponse.projectRequestHasNotDetailsResponse }
    const {details} = project
    return { hasError: false }
}

const validateProjectTasksIncidences = (project) => {
    if (!project.users && project.users.length < 1) return { hasError: true, errorResponse: projectResponse.projectRequestHasNotTasksResponse }
    return { hasError: false }
}

const validateProjectUsers = (project) => {
    if (!project.users && project.users.length < 1) return { hasError: true, errorResponse: projectResponse.projectRequestHasNotUsersResponse }
    return { hasError: false }
}


const validateProjectExist = (project) => {
    if ( !project || !project.data || !project.projectId ) return { hasError: true, errorResponse: projectResponse.projectDoesNotExistResponse}
    return { hasError: false }
}

module.exports = {
    validateNewProjectData,
    validateProjectDetails,
    validateProjectTasksIncidences,
    validateProjectUsers,
    validateProjectExist
}
