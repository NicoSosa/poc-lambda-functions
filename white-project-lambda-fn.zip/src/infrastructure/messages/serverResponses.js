const util = require('../../utils/util');

const serverErrorResponse = () => util.buildResponse(503, { message: 'Server Error. Please try again later.'});

module.exports = {
    serverErrorResponse
}