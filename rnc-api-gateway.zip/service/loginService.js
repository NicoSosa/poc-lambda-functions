const { DynamoDBClient, GetItemCommand } = require("@aws-sdk/client-dynamodb");
const { marshall, unmarshall } = require("@aws-sdk/util-dynamodb");
const db = new DynamoDBClient({ region: 'sa-east-1' });


const util = require('../utils/util');

const userTable = 'RNCUserTable';

const login = async (user) => {
    const mail = user.mail;
    const password = user.password;

    if (!user || !mail || !password ) {
        return util.buildResponse(400, { message: 'User and Password are required' })
    }

    const dynamoUser = await getUserByEmail(mail.toLowerCase().trim())

    if ( !dynamoUser || !dynamoUser.userName ) {
        return util.buildResponse(400, { message: 'User or Password incorrect' })
    }

    if (dynamoUser.password !== password) {
        return util.buildResponse(400, { message: 'User or Password incorrect' })
    }

    const response = {
        userName: dynamoUser.userName,
        userId: dynamoUser.token
    }

    return util.buildResponse(200, response)
}

async function getUserByEmail(mail) {
    const params = {
        TableName: userTable,
        Key: marshall({ userName: mail })
    }

    try {
        const command = new GetItemCommand(params);
        const response = await db.send(command);
        return unmarshall(response.Item)
    } catch (e) {
        return e
    }
}

module.exports.login = login;